package Projeto.Univel.Imoveis.DAO;

import Projeto.Univel.Imoveis.Factory.ConnectionFactory;
import Projeto.Univel.Imoveis.model.Imoveis;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ImoveisDAO {


    // CADASTRA MEU IMOVEIS
    public static void insertImovel(Imoveis imoveis) throws Exception {
        String sql = "INSERT INTO IMOVEIS(idimovel, matriculaimovel, proprietario," +
                "tipo, largura, comprimento, valor)" +
                "values(?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstm = null;
        try {
            // cria uma conexão com o Banco de dados
            conn = ConnectionFactory.createConnectionToMysql();

            // criamos uma PreparedStatement, para executar uma query
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            pstm.setInt(1, imoveis.getIdimovel());
            pstm.setString(2, imoveis.getMatriculaImovel());
            pstm.setString(3, String.valueOf(imoveis.getProprietario())); /* VAI TER QUE VALIDAR COMO IREMOS FAZER PARA A QUESTÃO DE PESSOA, SE VAI TRAZER PARA A PROPRIETARIO OU NÃO */
            pstm.setString(4, imoveis.getTipo());
            pstm.setDouble(5, imoveis.getLargura());
            pstm.setDouble(6, imoveis.getComprimento());
            pstm.setDouble(7, imoveis.getValor());
            pstm.execute();
            System.out.println("\nCADASTRO REALIZADO COM SUCESSO PARA: \nIMOVEL MATRICULA: " + imoveis.getMatriculaImovel());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // FECHAR AS CONEXOES
        }
        try {
            if (pstm != null) {
                pstm.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // BUSCA O CADASTRO DOS IMOVEIS
    public static ArrayList<Imoveis> getBuscaImoveis() {
        String sql = "SELECT * FROM IMOVEIS";
        ArrayList<Imoveis> imovel = new ArrayList<Imoveis>();
        Connection conn = null;
        PreparedStatement pstm = null;
        // CLASSE QUE VAI RECUPERAR OS DADOS DO BANCO, TRAZENDO A SELEÇÃO
        ResultSet rset = null;
        try {
            conn = ConnectionFactory.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            rset = pstm.executeQuery();
            // System.out.println("Sucesso!!");
            while (rset.next()) {
                Imoveis imo = new Imoveis();
                // pega os campo
                imo.setIdimovel(rset.getInt("idimovel"));
                imo.setMatriculaImovel(rset.getString("matriculaimovel"));
                imo.setProprietario(rset.getString("proprietario"));
                //imo.setProprietario((Pessoa) rset.getObject("proprietario"));
                imo.setTipo(rset.getString("tipo"));
                imo.setLargura(rset.getDouble("largura"));
                imo.setComprimento(rset.getDouble("comprimento"));
                imo.setValor(rset.getDouble("valor"));
                imovel.add(imo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // FECHAR AS CONEXOES
        }
        try {
            if (rset != null) {
                try {
                    rset.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (pstm != null) {
                try {
                    pstm.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
            if (conn != null) {
                try {
                    assert rset != null;
                    rset.close();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imovel;
    }

    // ATUALIZA O MEU IMOVEL
    public static void getAtualizaImovel(Imoveis imoveis) throws SQLException {
        String sql = "UPDATE IMOVEIS SET MATRICULAIMOVEL = ?, PROPRIETARIO = ?, TIPO = ?, LARGURA = ?, COMPRIMENTO = ?, VALOR = ? WHERE IDIMOVEL = ?";
        Connection conn = null;
        PreparedStatement pstm = null;
        try {
            conn = ConnectionFactory.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            pstm.setString(1, imoveis.getMatriculaImovel());
            pstm.setString(2, imoveis.getProprietario());
            //pstm.setString(3, String.valueOf(imovel.getProprietario())); /* VAI TER QUE VALIDAR COMO IREMOS FAZER PARA A QUESTÃO DE PESSOA, SE VAI TRAZER PARA A PROPRIETARIO OU NÃO */
            pstm.setString(3, imoveis.getTipo());
            pstm.setDouble(4, imoveis.getLargura());
            pstm.setDouble(5, imoveis.getComprimento());
            pstm.setDouble(6, imoveis.getValor());
            pstm.setInt(7, imoveis.getIdimovel());
            // EXECUTA O MEU UPDATE DO CADASTRO DO IMOVEL
            pstm.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                if(conn!=null) {
                    conn.close();
                }
            } catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    // DELETA OS MEUS REGISTROS DE IMOVEIS
    public static void apagaImovel(int idimovel) throws SQLException {
        String sql = "DELETE FROM IMOVEIS WHERE IDIMOVEL = ?";
        Connection conn = null;
        PreparedStatement pstm = null;
        try{
            conn = ConnectionFactory.createConnectionToMysql();
            pstm = (PreparedStatement) conn.prepareStatement(sql);
            pstm.setInt(1, idimovel);
            pstm.execute();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try{
                if(conn!=null){
                    conn.close();
                }
                if(pstm!=null){
                    pstm.close();
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
