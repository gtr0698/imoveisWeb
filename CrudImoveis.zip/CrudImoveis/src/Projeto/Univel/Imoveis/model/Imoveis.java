package Projeto.Univel.Imoveis.model;

public class Imoveis{

    private int idimovel;
    private String matriculaImovel;
    //private Pessoa proprietario;
    private String proprietario;
    private String tipo;
    private double largura;
    private double comprimento;
    private double valor;

    public Imoveis(int idimovel, String matriculaImovel, String proprietario, String tipo, double largura, double comprimento, double valor) {
        this.idimovel = idimovel;
        this.matriculaImovel = matriculaImovel;
        this.proprietario = proprietario;
        this.tipo = tipo;
        this.largura = largura;
        this.comprimento = comprimento;
        this.valor = valor;
    }

    public Imoveis() {

    }

    public int getIdimovel() {
        return idimovel;
    }
    public void setIdimovel(int idimovel) {
        this.idimovel = idimovel;
    }

    public String getMatriculaImovel() {
        return matriculaImovel;
    }
    public void setMatriculaImovel(String matriculaImovel) {
        this.matriculaImovel = matriculaImovel;
    }

    public String getProprietario() {
        return proprietario;
    }
    public void setProprietario(String proprietario) {
        this.proprietario = proprietario;
    }

    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public double getLargura() {
        return largura;
    }
    public void setLargura(double largura) {
        this.largura = largura;
    }

    public double getComprimento() {
        return comprimento;
    }
    public void setComprimento(double comprimento) {
        this.comprimento = comprimento;
    }

    public double getValor() {
        return valor;
    }
    public void setValor(double valor) {
        this.valor = valor;
    }
}
