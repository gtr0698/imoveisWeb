package Projeto.Univel.Imoveis.Input;

import java.util.Scanner;

public class Input {

    public static final Scanner leitor = new Scanner(System.in); //variável de leitura do teclado

    public static String next() {
        return leitor.next();
    }

    /**
     * *
     * Realiza a leitura da próxima linha digitada no terminal, a leitura até
     * localizar uma quebra de linha.
     *
     * @return Retorna uma String contendo o texto lido.
     */
    public static String nextLine() {
        // o comando useDelimiter("\\n") especifica para o leitor que o delimitador será a quebra de linha (\\n).
        // Desta forma o comando next() irá realizar a leitura de toda a linha digitada no terminal.
        return leitor.useDelimiter("\\n").next();
    }

    public static int nextInt() {
        while (true) { // laço de repetição infinito (para garantir que só irá sair da função após a leitura de um número válido)
            String valor = "";

            //trecho de código que pode vir a gerar (lançar) uma exceção. Veja mais em:  https://www.devmedia.com.br/tratando-excecoes-em-java/25514
            try {
                //realiza a leitura do teclado e armazena na variável valor do tipo String (texto).
                valor = leitor.next();

                //converte o valor que está no formato String (texto) para o formato int.
                //Se o processo de conversão for realizado com sucesso, o valor inteiro será retornado. Caso, haja um problema na conversão, será lancada um Exceção (Exception).
                return Integer.parseInt(valor);
            } catch (NumberFormatException e) { // A exceção do tipo NumberFormatException é capturada e tratada neste bloco de código
                //Quando a exceção do tipo NumberFormatException for gerada, a função irá informar o usuário e solicitar que seja digitado um valor novamente.
                System.out.println("Erro! o valor " + valor + " é inválido!");
                System.out.println("Informe um valor novamente:");
            }
        }
    }

    /**
     * *
     * Realiza a leitura do próxima número em ponto flutuante digitado no
     * terminal. Caso o valor informado seja inválido, será exibida uma mensagem
     * de erro e em seguida será solicitado que o número seja informado
     * novamente.
     *
     * @return Retorna um double contendo o número que foi lido.
     */
    public static double nextDouble() {
        while (true) {
            String valor = "";
            try {
                valor = leitor.next().replace(",", ".");
                return Double.parseDouble(valor);
            } catch (NumberFormatException e) {
                System.out.println("Erro! o valor " + valor + " é inválido!");
                System.out.println("Informe um valor novamente:");
            }
        }
    }
}
