package Projeto.Univel.Imoveis.Aplicacao;

import Projeto.Univel.Imoveis.DAO.ImoveisDAO;
import Projeto.Univel.Imoveis.Factory.ConnectionFactory;
import Projeto.Univel.Imoveis.Input.Input;
import Projeto.Univel.Imoveis.model.Imoveis;
import java.util.Objects;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import static Projeto.Univel.Imoveis.CRUD.CrudImovel.*;


public class Main {

    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);

        // METODO QUE VERIFICA A MINHA CONEXÃO COM O MEU BANCO DE DADOS
        ConnectionFactory.getcreateConnectionToMysql();
        //ConnectionFactory.createConnectionToMysql();

        Imoveis imoveis = new Imoveis();
        ImoveisDAO imoveisDAO = new ImoveisDAO();
        int opcao = 0;
        String decisao = "s";

        do {
            System.out.println("*** SISTEMA DE IMOVEL ***\n");
            System.out.println("[1] - Cadastro de Imovel");
            System.out.println("[2] - Atualizar Cadastro do Imovel");
            System.out.println("[3] - Lista de Imoveis");
            System.out.println("[4] - Deletar Imovel");
            System.out.print("Digite a Opção desejada: ");
            opcao = input.nextInt();
            switch (opcao) {
                case 1:
                    // METODO DE INSERT DE ALUNO
                    insertImovel();
                    break;
                case 2:
                    // METODO DE UPDATE DE ALUNO
                    getAtualizaImovel();
                    break;
                case 3:
                    // METODO DE LISTAGEM DE ALUNOS
                    getBuscaImoveis();
                    break;
                case 4:
                    // METODO DE DELETE
                    apagaImovel();
                    break;
            }
            System.out.print("\nDeseja realizar uma nova ação no Sistema [S/N]?: ");
            decisao = Input.nextLine();
        } while(Objects.equals(decisao, "S"));
        System.out.println("\nSISTEMA ENCERRADO COM SUCESSO!!");
    }
}