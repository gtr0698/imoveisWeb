package Projeto.Univel.Imoveis.Factory;

import java.sql.Connection;
import java.sql.Connection.*;
import java.sql.DriverManager;
public class ConnectionFactory {

    // NOME DO USUARIO DO MYSQL
    private static final String USER = "root";

    // SENHA DO BANCO
    private static final String PASSWORD = "";

    // CAMNHO DI BANCO DE DADOS, PORTA, NOME DO BANCO DE DADSOS
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/projetoimoveis";


    // CONEXÃO COM O BANCO DE DADOS
    public static Connection createConnectionToMysql() throws Exception{
        // FAZ COM QUE A CLASSE SEJA CARREGADA PELA A JVM
        Class.forName("com.mysql.cj.jdbc.Driver");
        // ClassLoader.getSystemClassLoader();
        //return DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
        return DriverManager.getConnection(DATABASE_URL, USER, PASSWORD);
    }

    public static void  main(String[] args) throws Exception {

        // RECUPERAR A CONEXÃO COM O BANCO DE DADOS;
        Connection con = createConnectionToMysql();

        // TESTAR SE A CONEXÃO É NULA;
        if(con!=null) {
            System.out.println("Conexão Obtida com Successo!!");
            con.close();
        } else {
            System.out.println("fudeu");
        }
    }

    public static void getcreateConnectionToMysql() {

    }
}
