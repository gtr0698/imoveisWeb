package Projeto.Univel.Imoveis.CRUD;

import Projeto.Univel.Imoveis.DAO.ImoveisDAO;
import Projeto.Univel.Imoveis.Input.Input;
import Projeto.Univel.Imoveis.model.Imoveis;
import java.sql.SQLException;


import java.sql.SQLException;
//import Projeto.Univel.Model.Pessoa;

public class CrudImovel {


    // CREATE DE IMOVEL - insertImovel
    public static void insertImovel() throws Exception {
        Imoveis imoveis = new Imoveis();
        System.out.println("\nCADASTRO DE IMOVEL\n");
        System.out.print("Digite a Matricula do Imovel: ");
        imoveis.setMatriculaImovel(Input.nextLine());
        System.out.print("Digite o Nome do Proprietário: ");
        imoveis.setProprietario(Input.nextLine());
        System.out.print("Digite o Tipo do Imovel: ");
        imoveis.setTipo(Input.nextLine());
        System.out.print("Digite a Largura do Imovel: ");
        imoveis.setLargura(Input.leitor.nextDouble());
        System.out.print("Digite o Comprimento do Imovel: ");
        imoveis.setComprimento(Input.leitor.nextDouble());
        System.out.print("Digite o Valor do Imovel: ");
        imoveis.setValor(Input.leitor.nextDouble());
        ImoveisDAO.insertImovel(imoveis);
    }

    // TRAZ A LISTAGEM DOS IMOVEIS - getBuscaImoveis
    public static void getBuscaImoveis(){
        System.out.println("\n\n**************************");
        System.out.println("     LISTA DE IMOVEIS    ");
        System.out.println("**************************\n");
        for(Imoveis i : ImoveisDAO.getBuscaImoveis()){
            System.out.println("Matricula do Imovel: " + i.getMatriculaImovel());
        }
    }

    // UPDATE DO CADASTRO DE IMOVEIS - getAtualizaImovel
    public static void getAtualizaImovel() throws Exception {
        // REALIZA A ATUALIZADO DO MEU IMOVEl
        // Aluno aluno = new Aluno();
        Imoveis imoveis = new Imoveis();
        ImoveisDAO imoveisDAO = new ImoveisDAO();
        //Aluno aluno = new Aluno();
        System.out.println("*********************************");
        System.out.println("\nATUALIZAÇÃO DE CADASTRO IMOVEL\n");
        System.out.println("\nCADASTRO DE IMOVEL\n");
        System.out.print("Digite a Matricula do Imovel: ");
        imoveis.setMatriculaImovel(Input.nextLine());
        System.out.print("Digite o Nome do Proprietário: ");
        imoveis.setProprietario(Input.nextLine());
        System.out.print("Digite o Tipo do Imovel: ");
        imoveis.setTipo(Input.nextLine());
        System.out.print("Digite a Largura do Imovel: ");
        imoveis.setLargura(Input.nextDouble());
        System.out.print("Digite o Comprimento do Imovel: ");
        imoveis.setComprimento(Input.nextDouble());
        System.out.print("Digite o Valor do Imovel: ");
        imoveis.setValor(Input.nextDouble());
        System.out.print("Digite o Código do Imovel: ");
        imoveis.setIdimovel(Input.nextInt());
        ImoveisDAO.getAtualizaImovel(imoveis);
        System.out.println("\nImovel Matricula: " +
                imoveis.getMatriculaImovel() + " atualizado com Sucesso!!");
    }

    // DELETA NOSSOS IMOVEIS - apagaImovel
    public static void apagaImovel() throws SQLException {
        Imoveis imoveis = new Imoveis();
        ImoveisDAO ImoveisDAO = new ImoveisDAO();
        System.out.print("\nDigite o ID do Imovel para a Deleção: ");
        imoveis.setIdimovel(Input.nextInt());
        ImoveisDAO.apagaImovel(imoveis.getIdimovel());
        System.out.println("Imovel Matricula: " + imoveis.getMatriculaImovel() + " removido com Sucesso!!");
    }
}
