package com.projeto.imoveis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImovelApplicationTests {

	@Test
	void contextLoads() {
	}

}
