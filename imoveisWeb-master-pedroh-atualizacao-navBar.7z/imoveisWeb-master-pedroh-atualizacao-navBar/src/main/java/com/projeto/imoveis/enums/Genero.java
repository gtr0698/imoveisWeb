package com.projeto.imoveis.enums;

public enum Genero {

    MASCULINO,
    FEMININO,
    OUTROS;
}
