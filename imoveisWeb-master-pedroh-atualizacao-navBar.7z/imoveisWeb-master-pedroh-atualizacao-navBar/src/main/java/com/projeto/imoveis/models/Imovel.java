package com.projeto.imoveis.models;

import com.projeto.imoveis.enums.TipoImovel;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

@Getter
@Setter
@Entity
public class Imovel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long idImovel;

    private String matriculaImovel;

    @ManyToOne
    private Pessoa proprietario;

    @Enumerated(EnumType.STRING)
    private TipoImovel tipoImovel;

    private double largura;

    private double comprimento;

    private double preco;

    public Imovel(String matriculaImovel,
                  Pessoa proprietario, TipoImovel tipoImovel,
                  double largura, double comprimento, double preco) {
        this.matriculaImovel = matriculaImovel;
        this.proprietario = proprietario;
        this.tipoImovel = tipoImovel;
        this.largura = largura;
        this.comprimento = comprimento;
        this.preco = preco;
    }

    public Imovel(){

    }

    public Imovel atualizaImovel(String matriculaImovel, Pessoa proprietario, TipoImovel tipoImovel,
                  double largura, double comprimento, double preco) {
        this.matriculaImovel = matriculaImovel;
        this.proprietario = proprietario;
        this.tipoImovel = tipoImovel;
        this.largura = largura;
        this.comprimento = comprimento;
        this.preco = preco;
    }
}
