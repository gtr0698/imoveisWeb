package com.projeto.imoveis.dto.imovel;

import com.projeto.imoveis.enums.TipoImovel;
import com.projeto.imoveis.models.Imovel;
import com.projeto.imoveis.models.Pessoa;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;

@Getter
public class ResponseImovelDto {

    private Long idImovel;
    private String matriculaImovel;
    private Pessoa proprietario;
    private TipoImovel tipoImovel;
    private double largura;
    private double comprimento;
    private double preco;

    public ResponseImovelDto(Imovel imovel) {
        this.idImovel = idImovel;
        this.matriculaImovel = matriculaImovel;
        this.proprietario = proprietario;
        this.tipoImovel = tipoImovel;
        this.largura = largura;
        this.comprimento = comprimento;
        this.preco = preco;
    }
}
