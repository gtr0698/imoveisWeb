package com.projeto.imoveis.enums;

public enum Papeis{

    CLIENTE, FUNCIONARIO;
}
