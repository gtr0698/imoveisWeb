package com.projeto.imoveis.enums;

public enum TipoImovel {

    RURAL,
    URBANO;
}