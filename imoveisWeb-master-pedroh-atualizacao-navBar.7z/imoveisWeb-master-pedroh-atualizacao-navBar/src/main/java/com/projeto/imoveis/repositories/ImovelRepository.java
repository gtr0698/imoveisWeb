package com.projeto.imoveis.repositories;

import com.projeto.imoveis.models.Imovel;
import com.projeto.imoveis.models.PessoaFisica;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ImovelRepository extends JpaRepository<Imovel, Long> {
}